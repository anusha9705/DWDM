age<-c(5,15,20,50,80,110)
frequency<-c(200,450,300,1500,700,44)
median(age)
median(frequency)

